import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import AppErrorBoundary from './AppErrorBoundary'
import './styles/observatory.css'
import './styles/refinement.css'
import '@fontsource-variable/alan-sans/wght.css'
import './styles/precision.css'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AppErrorBoundary><App /></AppErrorBoundary>
  </StrictMode>,
)

import './styles/workspace.css'
import './styles/accessibility.css'
