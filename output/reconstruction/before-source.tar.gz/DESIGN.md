---
name: EvidenceTwin Council
description: A slate and cobalt research workspace with preserved evidence revisions
colors:
  bg-page: "#f6f7fa"
  bg-surface: "#ffffff"
  bg-secondary: "#edf0f5"
  bg-navigation: "#eef0f5"
  text-primary: "#202737"
  text-secondary: "#596478"
  border-separator: "#dce1e9"
  border-control: "#8793a6"
  accent-solid: "#3159bb"
  accent-solid-hover: "#244596"
  accent-subtle: "#e5ebfb"
  accent-text: "#2a50ad"
  text-on-accent: "#ffffff"
  warning-text: "#80560f"
  danger-text: "#b3383b"
  data-series-a: "#416cbb"
  data-series-b: "#667a99"
  focus-ring: "#4e6ba6"
  dark-focus-ring: "#4e6ba6"
  dark-bg-page: "#11151c"
  dark-bg-surface: "#181e28"
  dark-bg-secondary: "#202836"
  dark-bg-navigation: "#151b25"
  dark-text-primary: "#eef1f7"
  dark-text-secondary: "#abb7ca"
  dark-border-separator: "#343f52"
  dark-border-control: "#6f809b"
  dark-accent-solid: "#9ebaff"
  dark-accent-solid-hover: "#c2d3ff"
  dark-accent-subtle: "#273650"
  dark-accent-text: "#b4caff"
  dark-text-on-accent: "#15244a"
  dark-warning-text: "#efc47a"
  dark-danger-text: "#ffb0b4"
  dark-data-series-a: "#9ebaff"
  dark-data-series-b: "#b1bfd5"
typography:
  headline:
    fontFamily: "Manrope, 'Alan Sans Variable', sans-serif"
    fontSize: "clamp(1.75rem,2.7vw,2.5rem)"
    fontWeight: 650
    lineHeight: 1.25
    letterSpacing: "-.025em"
  body:
    fontFamily: "Manrope, 'Alan Sans Variable', sans-serif"
    fontSize: "1rem"
    lineHeight: 1.65
  interface:
    fontSize: ".875rem"
  caption:
    fontSize: ".8125rem"
  label:
    fontSize: ".75rem"
  question:
    fontFamily: "Manrope, 'Alan Sans Variable', sans-serif"
    fontSize: "1.125rem"
    fontWeight: 400
    lineHeight: 1.85
  data:
    fontFamily: "'IBM Plex Mono', monospace"
rounded:
  control: "4px"
  attachment: "6px"
  composer: "12px"
spacing:
  space-1: "4px"
  space-2: "8px"
  space-3: "12px"
  space-4: "16px"
  space-6: "24px"
  space-8: "32px"
  space-12: "48px"
components:
  button-primary:
    backgroundColor: "{colors.accent-solid}"
    textColor: "{colors.text-on-accent}"
    rounded: "{rounded.control}"
    padding: "10px 16px"
  button-primary-hover:
    backgroundColor: "{colors.accent-solid-hover}"
  button-secondary:
    backgroundColor: "{colors.bg-surface}"
    textColor: "{colors.text-primary}"
    rounded: "{rounded.control}"
    padding: "10px 16px"
  navigation:
    backgroundColor: "{colors.bg-navigation}"
    rounded: "{rounded.control}"
    padding: "11px 12px"
  status:
    textColor: "{colors.accent-text}"
    padding: "3px 0"
  case-record:
    textColor: "{colors.text-primary}"
    padding: "24px 0"
  field:
    backgroundColor: "{colors.bg-surface}"
    rounded: "{rounded.control}"
    padding: "11px 12px"
  composer:
    backgroundColor: "{colors.bg-surface}"
    rounded: "{rounded.composer}"
    padding: "8px"
---

# Design System: EvidenceTwin Council

## Overview

**Creative North Star: "The annotated research notebook"**

The annotated research notebook keeps the scientific question beside preserved evidence, revisions and recorded review runs. Slate surfaces and cobalt actions support a calm, readable workspace. Original research content retains its supplied language; interface chrome supports English and Arabic.

This is a scan of the implemented system on 2026-11-07, replacing the prior green/sage documentation after the authorized transformation. CSS remains the runtime authority: `frontend/src/styles/precision.css`, `styles/observatory.css` and `features/analyses/research-entry.css`. The original document remains in the pre-task source snapshot. This document describes actual tokens; it does not approve scientific or pilot enablement.

**Key Characteristics:**

- A persistent scientific question and inspectable evidence history.
- Flat records, restrained borders and cobalt primary actions.
- Semantic light/dark themes and logical RTL layout.

## Colors

The frontmatter records exact light and dark semantic values. Cobalt `accent-solid` controls primary actions; `accent-text` handles links. Slate `bg-page`, `bg-secondary` and `bg-navigation` distinguish chrome from `bg-surface`. Primary/secondary text and separator/control borders remain separate roles. Warning/danger colors accompany written states; data-series colors are chart encodings, never verdicts.

Legacy aliases (`--bg`, `--paper`, `--surface`, `--ink`, `--muted`, `--line`, `--accent`, `--accent-hover`, `--accent-soft`, `--on-accent`, `--amber`, `--danger`) resolve to these semantic values. The effective focus-ring variable is `#4e6ba6` in both themes: the shared rule overrides the earlier light declaration. Use the active theme rather than copying dark tokens into light components.

## Typography

Manrope (variable 200–800) is locally loaded; Alan Sans Variable supplies Arabic. IBM Plex Mono is reserved for code, identifiers and numerical data, with tabular figures. Root body is 1rem/1.65. Shared headings use weight 650 and -.025em tracking; h2 is 1.25rem/1.4 and h3 1rem/1.5. Prose descriptions use 1rem/1.75 and a 66ch limit. Report prose has its own reading rhythm.

The question uses 1.125rem/1.85 at weight 400. Arabic removes negative tracking, uses Alan Sans and root leading 1.85; question leading is 1.9 and heading leading 1.6. At 760px, inputs and question text use 1rem. Preserve mixed-direction content with automatic direction and bidi isolation; changing interface language does not translate research.

## Layout

The shell retains a 236px sidebar and 64px utility header. The question-first entry has 56px 40px 64px outer padding and a centered 780px reading column. Saved cases use a flexible evidence column plus 248px provenance/history rail with 40px gap; below 1150px the rail stacks with a top separator. At 760px, entry padding becomes 32px 20px 40px, field pairs stack and controls wrap. The mobile shell uses bottom navigation and content clearance; preserve access to every destination through the shell. Use logical properties and wrap long scientific text and filenames.

The shared spacing scale in frontmatter is literal CSS. Preserve table overflow/inspection rather than compressing numerical content. Print hides the shell and uses plain report paper.

## Elevation & Depth

Records, charts and reports are flat; fills, separators and alignment carry hierarchy. Ordinary buttons have no shadow. The modal is the inherited exception: `0 20px 80px #10271f40` with backdrop `#10271f99`, without blur. These literal inherited overlay colors remain in `observatory.css`; they are not a new green semantic palette.

Controls transition background/border/color over 150ms ease. OS reduced-motion and the explicit reduced-motion setting remove animation, transitions and smooth scrolling.

## Shapes

Controls share 4px corners; attachment rows and dialogs use 6px. The question composer uses 12px corners. Records and reports remain flat with square edges where the dossier styles override inherited workspace radii. Status marks are circular and always paired with text.

## Components

Primary buttons use accent fill/on-accent text, 10px 16px padding, minimum 44px height and theme-specific hover. Quiet/secondary controls retain the same typography and target size. Disabled controls use .6 opacity. Generic keyboard focus uses a 3px accent outline offset by 3px.

Fields use a one-pixel control border, surface fill and 11px 12px padding. Focus changes the border to accent. Written errors are associated with inputs. The question textarea has no inner border, is resizable from 112px to 300px, and its containing composer shows a 2px focus-ring outline offset by 3px. Mobile minimum question height is 136px.

Sidebar links have an active paper surface and bold accent text. Status labels are inline written labels with a current-color dot; observatory styles remove the earlier pill border. Case rows use separators and explicit open links. Attachment rows show original names, local or saved state, and labeled removal/download actions. The provenance rail exposes original hashes and revision history.

Start Investigation persists a real case; Save revision creates an immutable snapshot. Council starts only through explicit consent against the saved revision. `ResearchEntry`, `ResearchCases`, `CaseDataset`, `SessionGate`, `AnalysisWorkspace` and existing inspection/report components implement these patterns. Scientific content is not decorative interface copy. See [the workflow](docs/PRODUCT_WORKFLOWS.md) for behavior.

## Do's and Don'ts

- Do resolve surfaces, text, controls and status through semantic CSS variables.
- Do preserve question, evidence revision and real review history as distinct records.
- Do use Manrope/Alan Sans for prose and IBM Plex Mono for code and numerical data.
- Do preserve original content direction with dir="auto", bdi and isolated code.
- Do keep visible focus, reduced motion and honest missing/failed/unavailable states.
- Do preserve official logo bytes, colors, proportions and orientation.

- Don't treat AI agreement, parsing or a completed run as scientific proof.
- Don't recolor or mirror the official artwork.
- Don't add decorative gradients, nested cards or fabricated findings.
- Don't present a URL as retrieved, a PDF as extracted or XLSX as supported.
