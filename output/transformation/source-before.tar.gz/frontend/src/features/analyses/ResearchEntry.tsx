import {lazy,Suspense,useEffect,useLayoutEffect,useRef,useState,useTransition} from 'react'
import type {FormEvent,KeyboardEvent} from 'react'
import {Link,useNavigate,useSearchParams} from 'react-router-dom'
import {ArrowUpRight,FilePlus2,X} from '../../components/ui/Icons'
import RouteLoading from '../../components/ui/RouteLoading'
import {prepareDraft,setDraftFiles,updateDraft,useAnalysisDraft} from './draft-store'
import {COMPOSER_ACCEPT,selectComposerEvidence,setPlannedEvidence,usePlannedEvidence} from './composer-evidence'
import './research-entry.css'

const Preparation=lazy(()=>import('./AnalysisBuilder'))

export default function ResearchEntry({ar}:{ar:boolean}){
 const [params]=useSearchParams()
 const {draft,files,modified}=useAnalysisDraft()
 const planned=usePlannedEvidence()
 const t=(en:string,arabic:string)=>ar?arabic:en
 useEffect(()=>{if(!modified&&planned.length)setPlannedEvidence([])},[modified,planned.length])
 if(params.has('prepare')||params.has('case'))return <>
  <div className="entry-handoff">
   <Link to="/app/analyses/new">{t('Edit research question','تعديل سؤال البحث')}</Link>
   {params.get('prepare')==='1'&&<p>{t('Local preparation only. Nothing has been uploaded or submitted.','إعداد محلي فقط. لم يُرفع أو يُرسل أي شيء.')}</p>}
   {planned.length>0&&<p className="planned-evidence-note">{t('XLSX files remain in the local composer and will not be submitted by the existing preparation flow: ','تبقى ملفات XLSX في المحرر المحلي ولن تُرسل عبر خطوات الإعداد الحالية: ')}{planned.map((file,i)=><span key={i}><bdi>{file.name}</bdi>{i<planned.length-1?', ':''}</span>)}</p>}
  </div>
  <Suspense fallback={<RouteLoading ar={ar}/>}><Preparation ar={ar}/></Suspense>
 </>
 return <ResearchComposer ar={ar} question={draft.claims[0]||''} files={files} planned={planned}/>
}

function ResearchComposer({ar,question,files,planned}:{ar:boolean;question:string;files:File[];planned:File[]}){
 const {draft,modified,pending,notice}=useAnalysisDraft()
 const t=(en:string,arabic:string)=>ar?arabic:en
 const navigate=useNavigate()
 const [opening,startTransition]=useTransition()
 const [panel,setPanel]=useState<'attachments'|'source'|'settings'|null>(null)
 const [source,setSource]=useState(draft.url)
 const [questionError,setQuestionError]=useState(false)
 const [sourceError,setSourceError]=useState(false)
 const [feedback,setFeedback]=useState('')
 const textarea=useRef<HTMLTextAreaElement>(null)
 const filePicker=useRef<HTMLInputElement>(null)
 const sourceInput=useRef<HTMLInputElement>(null)
 const attachmentButton=useRef<HTMLButtonElement>(null)
 const settingsButton=useRef<HTMLButtonElement>(null)
 const popover=useRef<HTMLDivElement>(null)
 const entry=useRef<HTMLDivElement>(null)
 const busy=pending||opening
 useEffect(()=>{prepareDraft()},[])
 useEffect(()=>{
  const input=textarea.current
  if(!input)return
  const resize=()=>{input.style.height='auto';input.style.height=Math.min(320,Math.max(160,input.scrollHeight))+'px'}
  resize();window.addEventListener('resize',resize)
  return()=>window.removeEventListener('resize',resize)
 },[question,ar])
 useLayoutEffect(()=>{
  if(!panel||!popover.current||!entry.current)return
  const anchor=(panel==='settings'?settingsButton:attachmentButton).current
  if(!anchor)return
  const anchorBox=anchor.getBoundingClientRect()
  const entryBox=entry.current.getBoundingClientRect()
  const height=popover.current.getBoundingClientRect().height
  const room=innerHeight-anchorBox.bottom-(innerWidth<=760?110:24)
  const top=room>=height?anchorBox.bottom+8:Math.max(12,anchorBox.top-height-8)
  popover.current.style.top=(top-entryBox.top)+'px'
 },[panel,files.length,planned.length,question,ar])
 useEffect(()=>{
  if(!panel)return
  if(panel==='source')sourceInput.current?.focus()
  else popover.current?.querySelector<HTMLElement>('button,select')?.focus()
  const dismiss=(event:globalThis.KeyboardEvent)=>{
   if(event.key==='Escape'){
    event.preventDefault();setPanel(null)
    ;(panel==='settings'?settingsButton:attachmentButton).current?.focus()
   }
  }
  const outside=(event:Event)=>{
   const target=event.target as Node
   if(!popover.current?.contains(target)&&!attachmentButton.current?.contains(target)&&!settingsButton.current?.contains(target))setPanel(null)
  }
  document.addEventListener('keydown',dismiss)
  document.addEventListener('pointerdown',outside)
  document.addEventListener('focusin',outside)
  return()=>{document.removeEventListener('keydown',dismiss);document.removeEventListener('pointerdown',outside);document.removeEventListener('focusin',outside)}
 },[panel])
 const issues={type:t('Choose a CSV, XLSX, PNG or JPG file.','اختر ملف CSV أو XLSX أو PNG أو JPG.'),size:t('Each file must be 20 MB or smaller.','يجب ألا يزيد حجم الملف عن ٢٠ ميغابايت.'),duplicate:t('That file is already attached.','هذا الملف مرفق بالفعل.')}
 function attach(incoming:File[]){
  const result=selectComposerEvidence([...files,...planned],incoming)
  setDraftFiles(result.files.filter(file=>!file.name.toLowerCase().endsWith('.xlsx')))
  setPlannedEvidence(result.files.filter(file=>file.name.toLowerCase().endsWith('.xlsx')))
  setFeedback(result.issues.map(issue=>issues[issue]).join(' ')||t('Evidence selected locally. No files have been uploaded.','اختيرت الأدلة محلياً. لم تُرفع أي ملفات.'))
  setPanel(null);attachmentButton.current?.focus()
 }
 function chooseFiles(accept:string){if(filePicker.current){filePicker.current.accept=accept;filePicker.current.click()}setPanel(null);attachmentButton.current?.focus()}
 function menuKeys(event:KeyboardEvent<HTMLDivElement>){
  if(!['ArrowDown','ArrowUp','Home','End'].includes(event.key))return
  const buttons=Array.from(event.currentTarget.querySelectorAll<HTMLButtonElement>('[role=menuitem]'))
  const current=buttons.indexOf(document.activeElement as HTMLButtonElement)
  const next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(current+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length
  event.preventDefault();buttons[next]?.focus()
 }
 function addSource(){
  try{
   const url=new URL(source.trim())
   if(!['http:','https:'].includes(url.protocol)||url.username||url.password)throw new Error()
   updateDraft({url:source.trim()});setSourceError(false);setPanel(null)
   setFeedback(t('Source link added locally. It has not been retrieved or verified.','أُضيف رابط المصدر محلياً. لم يُجلب محتواه أو يُتحقق منه.'))
   attachmentButton.current?.focus()
  }catch{setSourceError(true);sourceInput.current?.focus()}
 }
 function begin(event?:FormEvent){
  event?.preventDefault()
  if(busy)return
  if(!question.trim()){setQuestionError(true);textarea.current?.focus();return}
  setQuestionError(false);setPanel(null)
  startTransition(()=>navigate('/app/analyses/new?prepare=1'))
 }
 function removeFile(file:File,plannedFile:boolean){
  if(plannedFile)setPlannedEvidence(planned.filter(item=>item!==file))
  else setDraftFiles(files.filter(item=>item!==file))
  setFeedback(t('Attachment removed from this draft.','أُزيل المرفق من المسودة.'))
  textarea.current?.focus()
 }
 return <section className="research-entry" aria-labelledby="research-entry-title">
  <div className="research-entry-content" ref={entry}>
   <h1 id="research-entry-title">{t('What would you like to investigate?','ما الذي تودّ بحثه؟')}</h1>
   <p className="research-entry-intro">{t('Begin with a scientific claim or a research question.','ابدأ بادعاء علمي أو سؤال بحثي.')}</p>
   <form className={'research-composer'+(questionError?' has-error':'')} onSubmit={begin} aria-busy={busy}>
    <label htmlFor="research-question" className="sr-only">{t('Scientific claim or research question','الادعاء العلمي أو سؤال البحث')}</label>
    <textarea ref={textarea} id="research-question" className="research-question" dir="auto" value={question} maxLength={10000} rows={5} placeholder={t('What scientific claim would you like to investigate?','ما الادعاء العلمي الذي تودّ بحثه؟')} aria-invalid={questionError} aria-describedby={questionError?'research-question-error':'research-local-state'} disabled={busy} onChange={event=>{updateDraft({claims:[event.target.value,...draft.claims.slice(1)]});if(questionError&&event.target.value.trim())setQuestionError(false)}} onKeyDown={event=>{if((event.ctrlKey||event.metaKey)&&event.key==='Enter'&&!event.nativeEvent.isComposing){event.preventDefault();begin()}}}/>
    {questionError&&<p id="research-question-error" className="composer-error" role="alert">{t('Describe the claim or question you want to investigate.','اكتب الادعاء أو السؤال الذي تودّ بحثه.')}</p>}
    {files.length+planned.length>0||draft.url?<ul className="composer-attachments" aria-label={t('Selected evidence','الأدلة المختارة')}>
     {[...files,...planned].map((file,i)=>{const localOnly=planned.includes(file);return <li key={file.name+'-'+i}><span className="attachment-description"><bdi className="attachment-name" title={file.name}>{file.name}</bdi><span className="attachment-detail">{localOnly?t('XLSX · frontend only','XLSX · واجهة فقط'):t('Local file','ملف محلي')}</span></span><button type="button" disabled={busy} onClick={()=>removeFile(file,localOnly)} aria-label={t('Remove attachment ','إزالة المرفق ')+file.name}><X size={16}/></button></li>})}
     {draft.url&&<li><span className="attachment-description"><bdi className="attachment-name" title={draft.url}>{draft.url}</bdi><span className="attachment-detail">{t('Source link · not retrieved','رابط مصدر · لم يُجلب')}</span></span><button type="button" disabled={busy} onClick={()=>{updateDraft({url:''});setSource('');setFeedback(t('Source link removed.','أُزيل رابط المصدر.'));textarea.current?.focus()}} aria-label={t('Remove source URL','إزالة رابط المصدر')}><X size={16}/></button></li>}
    </ul>:null}
    <div className="composer-toolbar">
     <div className="composer-tools">
      <button type="button" className="composer-add" ref={attachmentButton} disabled={busy} aria-label={t('Add evidence','إضافة أدلة')} aria-haspopup="menu" aria-expanded={panel==='attachments'} aria-controls="composer-attachment-menu" onClick={()=>setPanel(panel==='attachments'?null:'attachments')}><span aria-hidden="true">+</span></button>
      <button type="button" ref={settingsButton} className="composer-settings" disabled={busy} aria-expanded={panel==='settings'} aria-controls="composer-settings-panel" onClick={()=>setPanel(panel==='settings'?null:'settings')}>{t('Research settings','إعدادات البحث')}</button>
     </div>
     <button type="submit" className="primary composer-start" disabled={busy}>{opening?t('Opening preparation…','جارٍ فتح الإعداد…'):t('Start Investigation','ابدأ البحث')}<ArrowUpRight size={18}/></button>
    </div>
   </form>
   <input className="sr-only" ref={filePicker} type="file" multiple accept={COMPOSER_ACCEPT} aria-label={t('Attach evidence files','إرفاق ملفات الأدلة')} tabIndex={-1} onChange={event=>{attach(Array.from(event.target.files||[]));event.target.value=''}}/>
   {panel&&<div ref={popover} className={'composer-popover composer-popover-'+panel}>
    {panel==='attachments'?<div id="composer-attachment-menu" role="menu" aria-label={t('Evidence attachments','مرفقات الأدلة')} onKeyDown={menuKeys}>
     <button type="button" role="menuitem" onClick={()=>chooseFiles('.csv,.xlsx')}><span>{t('Data files','ملفات البيانات')}</span><small dir="ltr">CSV, XLSX</small></button>
     <button type="button" role="menuitem" onClick={()=>chooseFiles('.png,.jpg,.jpeg')}><span>{t('Chart images','صور الرسوم')}</span><small dir="ltr">PNG, JPG</small></button>
     <button type="button" role="menuitem" onClick={()=>{setSource(draft.url);setSourceError(false);setPanel('source')}}><span>{t('Source URL','رابط المصدر')}</span><small>{t('Add a reference link','أضف رابط مرجع')}</small></button>
    <p className="composer-menu-note">{t('20 MB per file. XLSX stays local pending integration.','٢٠ ميغابايت لكل ملف. تبقى ملفات XLSX محلية حتى اكتمال التكامل.')}</p></div>:panel==='source'?<form onSubmit={event=>{event.preventDefault();addSource()}}>
     <label htmlFor="composer-source">{t('Source URL','رابط المصدر')}</label>
     <input ref={sourceInput} id="composer-source" type="text" inputMode="url" dir="ltr" maxLength={2000} value={source} autoComplete="off" placeholder="https://" aria-invalid={sourceError} aria-describedby={sourceError?'composer-source-error':undefined} onChange={event=>{setSource(event.target.value);setSourceError(false)}}/>
     {sourceError&&<p id="composer-source-error" className="composer-error" role="alert">{t('Enter a valid http or https URL without embedded credentials.','أدخل رابط http أو https صالحاً دون بيانات تسجيل دخول مضمنة.')}</p>}
     <div className="actions"><button type="submit" className="primary">{t('Add source','أضف المصدر')}</button><button type="button" onClick={()=>{setPanel(null);attachmentButton.current?.focus()}}>{t('Cancel','إلغاء')}</button></div>
    </form>:<div id="composer-settings-panel">
     <label>{t('Review mode','وضع المراجعة')}<select aria-label={t('Review mode','وضع المراجعة')} value={draft.mode} onChange={event=>updateDraft({mode:event.target.value as typeof draft.mode})}><option value="exploratory">{t('Exploratory','استكشافي')}</option><option value="verified">{t('Verified — requires service support','تحقق بالأدلة — يتطلب دعم الخدمة')}</option></select></label>
     <label>{t('Review depth','عمق المراجعة')}<select aria-label={t('Review depth','عمق المراجعة')} value={draft.reviewDepth} onChange={event=>updateDraft({reviewDepth:event.target.value as typeof draft.reviewDepth})}><option value="focused">{t('Focused Review','مراجعة مركزة')}</option><option value="council">{t('Full Council Review','مراجعة المجلس')}</option></select></label>
     <p>{t('Preferences for preparation. They do not enable a service or execute a review.','تفضيلات للإعداد. لا تُفعّل خدمة ولا تُنفّذ مراجعة.')}</p>
     <button type="button" onClick={()=>{setPanel(null);settingsButton.current?.focus()}}>{t('Done','تم')}</button>
    </div>}
   </div>}
   <p id="research-local-state" className="research-local-state">{t('Local draft. Nothing is uploaded or submitted until you review and confirm.','مسودة محلية. لا يُرفع أو يُرسل شيء قبل المراجعة والتأكيد.')}</p>
   <p className="composer-feedback" role="status">{feedback}</p>
   {notice==='restored'&&<p className="composer-feedback">{t('Saved text restored. Reattach any local files.','استُعيد النص المحفوظ. أعد إرفاق الملفات المحلية.')}</p>}
   {notice==='storage_error'&&<p className="composer-error" role="alert">{t('Browser storage is unavailable. Keep this tab open to retain your draft.','تخزين المتصفح غير متاح. أبقِ هذه النافذة مفتوحة للاحتفاظ بالمسودة.')}</p>}
   <div className="research-entry-links"><Link to="/app/library"><FilePlus2 size={16}/>{t('Explore research cases','استكشف حالات بحثية')}</Link>{modified&&<Link to="/app/analyses/new?prepare=1">{t('Review preparation','مراجعة الإعداد')}</Link>}</div>
  </div>
 </section>
}
