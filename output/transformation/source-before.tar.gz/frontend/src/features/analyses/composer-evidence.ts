import {useSyncExternalStore} from 'react'
import {MAX_FILE_BYTES} from './files'

/** Planned XLSX attachments stay in this tab and never enter the current API file list. */
let planned:File[]=[]
const listeners=new Set<()=>void>()
export function setPlannedEvidence(files:File[]){planned=files;listeners.forEach(listener=>listener())}
export function usePlannedEvidence(){return useSyncExternalStore(listener=>{listeners.add(listener);return()=>{listeners.delete(listener)}},()=>planned)}
export const COMPOSER_ACCEPT='.csv,.xlsx,.png,.jpg,.jpeg'
export function selectComposerEvidence(existing:File[],incoming:File[]){
 const files=[...existing]
 const issues:('type'|'size'|'duplicate')[]=[]
 for(const file of incoming){
  if(!/\.(csv|xlsx|png|jpe?g)$/i.test(file.name)){issues.push('type');continue}
  if(file.size>MAX_FILE_BYTES){issues.push('size');continue}
  if(files.some(item=>item.name===file.name&&item.size===file.size&&item.lastModified===file.lastModified)){issues.push('duplicate');continue}
  files.push(file)
 }
 return {files,issues:[...new Set(issues)]}
}
