---
name: EvidenceTwin Council
description: A traceable research dossier with precise, evidence-linked interfaces.
colors:
  "bg-page": "#f8faf8"
  "bg-surface": "#ffffff"
  "bg-secondary": "#eef3ef"
  "bg-navigation": "#e8efea"
  "text-primary": "#203a33"
  "text-secondary": "#52665f"
  "border-separator": "#d3ded7"
  "border-control": "#75877e"
  "accent-solid": "#276757"
  "accent-solid-hover": "#1c5144"
  "accent-subtle": "#dcebe2"
  "accent-text": "#245e50"
  "text-on-accent": "#ffffff"
  "warning-text": "#805719"
  "danger-text": "#a03936"
  "data-series-a": "#466fa2"
  "data-series-b": "#277a77"
  "dark-bg-page": "#14231f"
  "dark-bg-surface": "#1b2e27"
  "dark-bg-secondary": "#243b31"
  "dark-bg-navigation": "#192e25"
  "dark-text-primary": "#edf3ee"
  "dark-text-secondary": "#b4c7bb"
  "dark-border-separator": "#3c5446"
  "dark-border-control": "#8fa99a"
  "dark-accent-solid": "#acd5bd"
  "dark-accent-solid-hover": "#c8e8d3"
  "dark-accent-subtle": "#2c4938"
  "dark-accent-text": "#b6dfc5"
  "dark-text-on-accent": "#163020"
  "dark-warning-text": "#edc482"
  "dark-danger-text": "#ffb6a7"
  "dark-data-series-a": "#9dbce9"
  "dark-data-series-b": "#8ad2c5"
typography:
  display:
    fontFamily: "Manrope, 'Alan Sans Variable', sans-serif"
    fontSize: "clamp(2rem,4vw,3rem)"
    fontWeight: 650
    lineHeight: 1.25
    letterSpacing: "-.035em"
  headline:
    fontFamily: "Manrope, 'Alan Sans Variable', sans-serif"
    fontSize: "clamp(1.75rem,2.5vw,2.25rem)"
    fontWeight: 650
    lineHeight: 1.3
    letterSpacing: "-.03em"
  composer-heading:
    fontFamily: "Manrope, 'Alan Sans Variable', sans-serif"
    fontSize: "clamp(1.75rem,2.7vw,2.25rem)"
    fontWeight: 650
    lineHeight: 1.4
    letterSpacing: "-.03em"
  title:
    fontFamily: "Manrope, 'Alan Sans Variable', sans-serif"
    fontSize: "1.25rem"
    fontWeight: 650
    lineHeight: 1.4
    letterSpacing: "-.025em"
  body:
    fontFamily: "Manrope, 'Alan Sans Variable', sans-serif"
    fontSize: "1rem"
    lineHeight: 1.65
    letterSpacing: "0"
  interface:
    fontFamily: "Manrope, 'Alan Sans Variable', sans-serif"
    fontSize: ".875rem"
    fontWeight: 600
    lineHeight: 1.5
  caption:
    fontFamily: "Manrope, 'Alan Sans Variable', sans-serif"
    fontSize: ".8125rem"
    lineHeight: 1.65
    letterSpacing: "0"
  label:
    fontFamily: "Manrope, 'Alan Sans Variable', sans-serif"
    fontSize: ".75rem"
  question:
    fontFamily: "Manrope, 'Alan Sans Variable', sans-serif"
    fontSize: "1.125rem"
    fontWeight: 400
    lineHeight: 1.85
  arabic-body:
    fontFamily: "'Alan Sans Variable', sans-serif"
    fontSize: "1rem"
    lineHeight: 1.85
  code:
    fontFamily: "'IBM Plex Mono', monospace"
    fontSize: ".8125rem"
    lineHeight: 1.8
rounded:
  "flat": "0"
  "control": "4px"
  "popover": "6px"
  "composer": "8px"
spacing:
  "1": "4px"
  "2": "8px"
  "3": "12px"
  "4": "16px"
  "6": "24px"
  "8": "32px"
  "12": "48px"
components:
  button-primary:
    backgroundColor: "{colors.accent-solid}"
    textColor: "{colors.text-on-accent}"
    typography: "{typography.interface}"
    rounded: "{rounded.control}"
    padding: "10px 16px"
  button-primary-hover:
    backgroundColor: "{colors.accent-solid-hover}"
    textColor: "{colors.text-on-accent}"
  button-secondary:
    backgroundColor: "{colors.bg-surface}"
    textColor: "{colors.text-primary}"
    typography: "{typography.interface}"
    rounded: "{rounded.control}"
    padding: "10px 16px"
  button-quiet:
    backgroundColor: "transparent"
    textColor: "{colors.accent-solid}"
    rounded: "{rounded.control}"
    padding: "10px 16px"
  input:
    backgroundColor: "{colors.bg-surface}"
    textColor: "{colors.text-primary}"
    rounded: "{rounded.control}"
    padding: "11px 12px"
  nav-active:
    backgroundColor: "{colors.bg-surface}"
    textColor: "{colors.accent-text}"
    rounded: "{rounded.control}"
    padding: "11px 12px"
  status-label:
    backgroundColor: "transparent"
    textColor: "{colors.text-primary}"
    rounded: "{rounded.flat}"
    padding: "3px 0"
  notice:
    backgroundColor: "{colors.bg-secondary}"
    textColor: "{colors.text-primary}"
    rounded: "{rounded.flat}"
    padding: "20px"
  reviewer-record:
    backgroundColor: "transparent"
    rounded: "{rounded.flat}"
    padding: "28px 0"
  research-composer:
    backgroundColor: "{colors.bg-surface}"
    rounded: "{rounded.composer}"
    padding: "8px 8px 12px"
---
# Design System: EvidenceTwin Council

## Overview

**Creative North Star: "Research dossier — critical edition"**

Research reads as a traceable dossier: cool paper, forest ink, sage navigation and aligned commentary. A clear claim leads into evidence, independent reviews and recorded conclusions; the interface distinguishes evidence from interpretation and uncertainty.

The shared system uses restrained sans-serif typography, flat separators and compact square controls. English and Arabic share a visual hierarchy while scientific content keeps its supplied language and direction. The official owner-supplied logo remains unchanged in color, proportion and orientation.

**Key Characteristics:**

- Cool paper and forest ink with sage navigation.
- Flat records and aligned reviewer-role gutters.
- Manrope interface with Alan Sans Arabic; technical monospace for code and measurements.
- Visible focus, readable mixed-direction content and responsive reflow.

This is a source-extracted record of the implemented redesign and prompt-first amendment, not a new visual proposal. Source authority: `frontend/src/main.tsx` loads the base application styles, workspace styles, `styles/precision.css`, `styles/observatory.css`, then accessibility refinements. `features/analyses/research-entry.css` owns the composer. Frontmatter is normative for the extracted primitives; CSS remains the implementation authority. `docs/DESIGN_SYSTEM.md` preserves the earlier system and is left intact. This documentation pass did not perform browser validation.

## Colors

### Primary

Forest accent (`accent-solid`) identifies primary actions and selected phases; its hover counterpart provides the interactive state. The separate accent text and subtle accent fill support links and selected navigation without treating every panel as an action. On-accent text changes with the theme.

### Neutral

Cool page paper, white surface paper, secondary sage fill and navigation sage form four distinct surface roles. Forest primary ink and quieter secondary ink separate findings from metadata. Separator borders are lighter than control borders; interactive fields remain easy to locate. Every light role has its exact implemented `dark-` counterpart in the frontmatter; dark mode is a semantic replacement rather than inversion.

Warning and danger text identify limited/awaiting and failed/cancelled states, with written labels. Data series A and B are chart colors, not assessment verdicts.

**The Semantic Theme Rule.** Resolve colors through the active semantic CSS variables; use the dark values only through the theme, not as isolated light-theme accents.

## Typography

**Display and body:** Manrope with Alan Sans Variable and sans-serif fallbacks. **Arabic:** Alan Sans Variable. **Code and data:** IBM Plex Mono with monospace fallback, using tabular numbers for measurements. Manrope is locally loaded with variable weights (200–800); Alan Sans is imported through its variable font package.

The frontmatter captures public editorial display, workspace headline, composer heading, title, body, interface, caption, label, question and code roles. Workspace section headings often step down to (1.125rem); reviewer role headings use (1rem, 650, 1.6). The principal claim uses (1.375rem, 500, 1.7), becoming (1.125rem) on mobile. Editorial/report prose uses (1rem, 1.85); ordinary descriptions use (1rem, 1.75) and about (66ch), while report prose is limited to (70ch).

Arabic removes negative tracking and increases heading leading to (1.6); root Arabic body leading is (1.85). The question field uses plaintext bidi and automatic direction. Code stays isolated LTR; source identifiers and filenames use bidi isolation. Captions, metadata and navigation use the interface font rather than an ornamental terminal face.

**The Content Type Rule.** Assign monospace to actual code and numerical data, not explanatory research prose.

## Layout

The desktop research shell has a fixed sage sidebar (236px), collapsed sidebar (76px), sticky utility header (64px), and breadcrumb strip with a minimum height of (48px). Page width caps at (1440px), with (32px) side padding, increasing to (48px) at large desktop widths. Public reading layouts cap at (1320px); documentation pairs a (230px) navigation rail with a flexible reading column and (48px) gap.

The shared spacing scale is extracted in the frontmatter. Normal records use separators and (20–28px) vertical rhythm, rather than repeated enclosing boxes. Dashboard content pairs a flexible record column with a (260px) rail and (32px) gap. Reviewer comparisons use an aligned identity gutter (150–220px) and reading column separated by a (32px) gap. Compact density reduces selected record and reviewer row padding to (14px).

At (1150px), dashboard and preparation side rails stack, the draft summary stops sticking, and evidence categories become a select. At (1100px), public article side navigation disappears and the reading layout becomes one column; case thumbnails narrow. At (900px), analysis tables turn into labeled record rows and documentation navigation narrows. At (760px), the app switches to four bottom navigation destinations, preserves a safe-area inset and content clearance, uses (20px) page gutters, stacks reviewer gutters and documentation navigation, and simplifies preparation progress to five bars. Accessibility refinements also use (48rem), including wrapped headers and stacked summaries. At (600px), retained workspace rules simplify pagination and record grids. At (1600px), app page gutters expand; the inherited (1500px) dashboard rule is superseded by the shared dossier grid.

The prompt-first entry centers a single column capped at (820px), with desktop outer padding (48px 40px 80px). Its question leads, attachments follow, and the lower toolbar holds evidence, settings and Start Investigation. At (1000px), side padding becomes (32px); at (760px), the heading aligns to the reading edge, question text becomes (1rem), the toolbar wraps and attachment rows fill available width. At (360px), Start Investigation spans the full toolbar width. This page-specific composition does not replace the record layout elsewhere.

Use logical properties for RTL. Only explicitly directional icons flip; the official logo never does. Print removes the shell, uses white paper and keeps the report reading column.

## Elevation & Depth

Research surfaces are flat: tonal fills, one-pixel separators and stronger control borders establish hierarchy. Tables, charts, reports and reviewer records have no resting shadow. The modal dialog is the deliberate elevated exception: `0 20px 80px #10271f40`, with backdrop `#10271f99`; popovers rely on a border and stacking rather than a shadow. Do not add blur or decorative surface lifting.

**The Flat Record Rule.** Separate adjacent research records with alignment and rules; reserve elevation for modal interruption.

Buttons and the composer border transition over (150ms ease); inherited record hover uses (160ms ease). Route and preparation entry use small (5px) translations over (200ms/180ms ease-out). Reduced-motion preferences and the explicit reduced-motion setting remove animation, transitions and smooth scrolling.

## Shapes

The recurring language is square and restrained. Controls, sidebar destinations, attachments and dropzones use the control radius; records, notices, comparison sections, tables and reports are flat. Composer attachment/source/settings popovers and dialogs use the popover radius; the question composer alone uses the larger composer radius. Evidence-category and documentation links retain (3px) corners. Status dots are circular, paired with text.

The app-layout scope explicitly resets both workspace and control radius variables to (4px), so selectors inherited from the earlier workspace system resolve to the same shared control corners. Flat dossier surfaces override those radii to zero.

## Components

### Buttons

Primary buttons use forest fill and on-accent text, with the darker/lighter theme-specific hover token. Secondary buttons use paper with a control border; quiet buttons use transparent background and accent text. The standard control is at least (44px) high with (10px 16px) padding. Hover changes background/border without brightness filters. Disabled controls use (.6) opacity. Keyboard focus is a (3px) accent outline offset by (3px); file-input wrappers use (4px) offset. Compact sidebar toggles are a deliberate (32px) exception.

### Fields

Fields use paper, a one-pixel control border and (11px 12px) padding. Focus changes border to the accent and retains the visible outline. Inputs/selects remain at least (44px) high; at mobile widths field text is (1rem). Error messages remain written and associated with their input; placeholder text uses secondary ink at full opacity.

### Navigation

Sidebar destinations are (44px) minimum, use (11px 12px) padding, and show a paper active surface with bold accent text. Hover uses the subtle accent fill. Collapsing keeps accessible names and hides only visible labels. Mobile bottom destinations stack icon and label in (60px) minimum targets, while the utility navigation retains other routes. Article/docs navigation is quiet, aligned to reading columns and moves into the flow when space is constrained.

### Status labels and attachment tags

Status is an inline text label with a small current-color dot, no enclosing pill and (3px 0) padding. Running/queued use accent text, failure/cancellation use danger, and awaiting evidence/limited completion use warning text. Attachment tags are local-selection rows with secondary fill, control-radius corners, truncated filename, smaller explanatory line and a labeled removal button. On mobile they fill the composer width.

### Notices, cards and empty states

Notices use secondary fill, a separator border and (20px) padding; errors replace the border with danger. Empty/loading/error research states use horizontal rules and secondary fill, with left/start alignment rather than decorative illustrations. Reports keep a plain paper sheet with one border and (36px) padding, becoming (24px 20px) on mobile. Source and library records remain separator-based rows.

### Reviewer-role gutter

Council review places a role title and responsibility beside the associated execution record. Each row ends with a rule. Reading copy, status, model metadata and source citations stay in a consistent second column; missing execution is explicitly written as “No execution record supplied.” The gutter stacks above the content on mobile. AI agreement is not a scientific verdict.

### Research question composer

The form is a bordered paper surface with a single (8px) corner radius. A (160–320px) resizable question field uses (20px 20px 12px) padding and no interior border. Parent focus-within uses an accent-text border and one-pixel outline. Error state changes the border and presents a written validation message. The question is required; Ctrl/Cmd+Enter opens preparation. Evidence and settings are secondary controls; menus support arrow/Home/End navigation, Escape dismissal and focus restoration.

The attachment menu accepts CSV/XLSX datasets and PNG/JPG images plus one HTTP(S) source link. Its contextual note states the (20 MB) per-file limit and local-only XLSX boundary. Selection is local; source content is not retrieved or verified. XLSX stays in tab memory outside API files and is labeled “frontend only.” Start Investigation navigates to the existing preparation at `/app/analyses/new?prepare=1`; it does not upload, submit or execute. Educational `?case=` links continue directly to preparation. Preserve these truthful state labels when applying the visual pattern.

## Do's and Don'ts

- Do use semantic theme variables for surfaces, text, controls and scientific status.
- Do keep explanatory copy in Manrope or Alan Sans and reserve monospace for code or data.
- Do retain source direction with dir="auto", bdi and isolated LTR code.
- Do preserve the official artwork under frontend/public/brand/ without mirroring it.
- Do identify local drafts, educational examples, unavailable checks and unverified sources explicitly.
- Do keep keyboard focus visible and honor reduced motion.

- Don't infer scientific truth from AI agreement or color alone.
- Don't turn flat research records into nested decorative cards or add gradients.
- Don't recolor, redraw, stretch or mirror the supplied logos.
- Don't present selected files as uploaded, a URL as retrieved or XLSX as backend-supported.
- Don't compress scientific prose to preserve a desktop multi-column arrangement.
